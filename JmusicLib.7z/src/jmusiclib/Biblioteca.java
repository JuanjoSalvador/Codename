package jmusiclib;

/**
 *
 * @author Juanjo Salvador
 */
public class Biblioteca {
    
}
